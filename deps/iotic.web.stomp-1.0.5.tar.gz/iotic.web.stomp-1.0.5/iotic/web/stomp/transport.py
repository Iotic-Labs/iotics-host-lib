import logging
import math
import random
import socket
import threading
import time
import warnings
from collections import namedtuple
from typing import Optional

import stomp.exception as exception
import websocket
from stomp.transport import BaseTransport, ssl
from urllib3.util import parse_url

log = logging.getLogger('stomp.py')

KeepAlive = namedtuple('KeepAlive', ('tcp_idle', 'tcp_intvl', 'tcp_cnt'))


class SSLConnectionError(exception.StompException):
    pass


class WSTransport(BaseTransport):
    """
        Websocket transport extending Stomp.py BaseTransport
    """

    def __init__(self,
                 endpoint: str,
                 reconnect_sleep_initial=0.1,
                 reconnect_sleep_increase=0.5,
                 reconnect_sleep_jitter=0.1,
                 reconnect_sleep_max=60.0,
                 reconnect_attempts_max=3,
                 use_ssl=False,
                 ssl_key_file=None,
                 ssl_cert_file=None,
                 ssl_ca_certs=None,
                 ssl_cert_validator=None,
                 ssl_version=None,
                 timeout=None,
                 keepalive: KeepAlive = None,
                 vhost=None,
                 auto_decode=True,
                 encoding='utf-8'
                 ):
        BaseTransport.__init__(self, auto_decode, encoding)

        self.endpoint = endpoint
        self.__reconnect_sleep_initial = reconnect_sleep_initial
        self.__reconnect_sleep_increase = reconnect_sleep_increase
        self.__reconnect_sleep_jitter = reconnect_sleep_jitter
        self.__reconnect_sleep_max = reconnect_sleep_max
        self.__reconnect_attempts_max = reconnect_attempts_max
        self.__timeout = timeout
        self.__socket_semaphore = threading.BoundedSemaphore(1)
        self.socket: Optional[websocket.WebSocket] = None
        self.__keepalive = keepalive
        self.vhost = vhost
        _, _, host, port, *_ = parse_url(self.endpoint)
        self.current_host_and_port = (host, port)
        self.ssl_params = {}

        if use_ssl:
            # kept for compatibility with stomp.py
            warnings.warn('Deprecated: use set_ssl instead', DeprecationWarning)
            self.set_ssl(self.current_host_and_port,
                         ssl_key_file,
                         ssl_cert_file,
                         ssl_ca_certs,
                         ssl_cert_validator,
                         ssl_version)

    def is_connected(self) -> bool:
        try:
            return self.socket and self.socket.connected
        except websocket.WebSocketException:
            return False

    def disconnect_socket(self):
        self.running = False
        self.cleanup()
        self.notify('disconnected')

    def send(self, encoded_frame: bytes):
        if self.socket is not None:
            try:
                with self.__socket_semaphore:
                    self.socket.send(encoded_frame)
            except websocket.WebSocketException as err:
                log.exception('Error sending frame')
                raise err
        else:
            raise exception.NotConnectedException()

    def receive(self) -> bytes:
        try:
            return self.socket.recv()
        except websocket.WebSocketException:
            if self.is_connected():
                raise

    def cleanup(self):
        try:
            if self.socket is not None:
                self.socket.close()
        except websocket.WebSocketException:
            log.exception('Can not close websocket')
        finally:
            self.socket = None

    def get_keep_alive_options(self) -> list:
        if self.__keepalive:
            return [(socket.SOL_TCP, socket.TCP_KEEPIDLE, self.__keepalive.tcp_idle),
                    (socket.SOL_TCP, socket.TCP_KEEPINTVL, self.__keepalive.tcp_intvl),
                    (socket.SOL_TCP, socket.TCP_KEEPCNT, self.__keepalive.tcp_cnt)]
        return []

    def run_custom_cert_validator(self):
        server_cert_validator = self.ssl_params.get('cert_validator')
        if server_cert_validator:
            cert = self.socket.sock.getpeercert()
            valid, errmsg = server_cert_validator(cert, self.current_host_and_port[0])
            if not valid:
                raise SSLConnectionError(f'Server certificate validation failed: {errmsg}')

    def attempt_connection(self):
        self.connection_error = False
        sleep_exp = 1
        connect_count = 0
        while self.running and self.socket is None and (
                connect_count < self.__reconnect_attempts_max or self.__reconnect_attempts_max == -1):
            try:
                log.info('Attempting connection to %s', self.endpoint)
                self.socket = websocket.create_connection(self.endpoint, timeout=self.__timeout,
                                                          sockopt=self.get_keep_alive_options(),
                                                          sslopt=self.ssl_params)
                log.info('Established connection to %s', self.endpoint)
                self.run_custom_cert_validator()
                break
            except ssl.SSLError as err:
                raise SSLConnectionError(err) from err
            except websocket.WebSocketException:
                self.socket = None
                connect_count += 1
                log.warning('Could not connect to %s', self.endpoint)

            if self.socket is None:
                sleep_exp = self.wait_before_retry(sleep_exp)

        if not self.socket:
            raise exception.ConnectFailedException()

    def wait_before_retry(self, sleep_exp):
        """
        Code extracted from stomp.py Transport
        """
        sleep_duration = (min(self.__reconnect_sleep_max,
                              ((self.__reconnect_sleep_initial / (1.0 + self.__reconnect_sleep_increase))
                               * math.pow(1.0 + self.__reconnect_sleep_increase, sleep_exp)))
                          * (1.0 + random.random() * self.__reconnect_sleep_jitter))
        sleep_end = time.monotonic() + sleep_duration
        log.debug('Sleeping for %.1f seconds before attempting reconnect', sleep_duration)
        while self.running and time.monotonic() < sleep_end:
            time.sleep(0.2)
        if sleep_duration < self.__reconnect_sleep_max:
            sleep_exp += 1
        return sleep_exp

    def set_ssl(self,
                for_host=None,  # pylint: disable=W0613 # Not used but kept for compatibility with stomp.py
                key_file=None,
                cert_file=None,
                ca_certs=None,
                cert_validator=None,
                ssl_version=ssl.PROTOCOL_SSLv23,
                password=None,
                verify: bool = True):
        """
       Sets up SSL configuration for the given hosts. Raises an exception if the SSL module can't be found.

       :param cert_file: the path to a X509 certificate
       :param key_file: the path to a X509 key file
       :param ca_certs: the path to the a file containing CA certificates to validate the server against.
                        If this is not set, server side certificate validation is not done.
       :param cert_validator: function which performs extra validation on the client certificate, for example
                              checking the returned certificate has a commonName attribute equal to the
                              hostname (to avoid man in the middle attacks).
                              The signature is: (OK, err_msg) = validation_function(cert, hostname)
                              where OK is a boolean, and cert is a certificate structure
                              as returned by ssl.SSLSocket.getpeercert()
       :param ssl_version: SSL protocol to use for the connection. This should be one of the PROTOCOL_x
                           constants provided by the ssl module. The default is ssl.PROTOCOL_SSLv23
       """
        self.ssl_params = dict(keyfile=key_file,
                               certfile=cert_file,
                               ca_certs=ca_certs,
                               cert_validator=cert_validator,
                               ssl_version=ssl_version,
                               password=password)
        if not verify:
            self.ssl_params['cert_reqs'] = ssl.CERT_NONE

    def get_ssl(self, host_and_port=None):  # pylint: disable=W0613 # Not used but kept for compatibility with stomp.py
        return self.ssl_params
