import threading
from collections import namedtuple

from retry.api import retry_call
from stomp import ConnectionListener
from stomp.connect import BaseConnection, Protocol12, ssl
from stomp.exception import StompException

from iotic.web.stomp.transport import KeepAlive, WSTransport

INTERNAL_CONNECTED_LISTENER_NAME = '__internal__wait_for_connected__'


class StompConnectionError(StompException):
    """
        Raised if an error occurs during the connect process
    """


class StompConnectionTimeout(StompException):
    """
        Error sent when connect is called with wait=True and the user timeout is reached before
        the connected frame is received
    """


StompFrame = namedtuple('StompFrame', ('headers', 'body'))


class WaitForConnectedListener(ConnectionListener):
    def __init__(self):
        self.connected_frame_received: bool = False
        self.error: StompFrame = None

    def is_connected(self) -> bool:
        """
        Returns true if the "CONNECTED" frame has been received.
        Raises a StompConnectionError if an error occured
        """
        if self.error:
            raise StompConnectionError(f'Can not connect to the stomp server: {self.error.headers} - {self.error.body}')
        return self.connected_frame_received

    def on_connected(self, headers, body):
        super().on_connected(headers, body)
        self.connected_frame_received = True

    def on_error(self, headers, body):
        super().on_error(headers, body)
        self.error = StompFrame(headers, body)


class StompWSConnection12(BaseConnection, Protocol12):
    """
        Extends stomp.py StompConnection12 using Websocket transport
    """

    def __init__(self,
                 endpoint: str,
                 reconnect_sleep_initial=0.1,
                 reconnect_sleep_increase=0.5,
                 reconnect_sleep_jitter=0.1,
                 reconnect_sleep_max=60.0,
                 reconnect_attempts_max=3,
                 use_ssl=False,
                 ssl_key_file=None,
                 ssl_cert_file=None,
                 ssl_ca_certs=None,
                 ssl_cert_validator=None,
                 ssl_version=ssl.PROTOCOL_SSLv23,
                 timeout=None,
                 heartbeats=(0, 0),
                 keepalive: KeepAlive = None,
                 vhost=None,
                 auto_decode=True,
                 encoding='utf-8',
                 auto_content_length=True,
                 heart_beat_receive_scale=1.5):
        transport = WSTransport(endpoint,
                                reconnect_sleep_initial,
                                reconnect_sleep_increase,
                                reconnect_sleep_jitter,
                                reconnect_sleep_max,
                                reconnect_attempts_max,
                                use_ssl,
                                ssl_key_file,
                                ssl_cert_file,
                                ssl_ca_certs,
                                ssl_cert_validator,
                                ssl_version,
                                timeout,
                                keepalive,
                                vhost,
                                auto_decode,
                                encoding)

        BaseConnection.__init__(self, transport)
        Protocol12.__init__(self, transport, heartbeats, auto_content_length,
                            heart_beat_receive_scale=heart_beat_receive_scale)
        self.connected = False
        self.lock = threading.Lock()

    def set_listener(self, name, lstnr):
        with self.lock:
            if self.connected:
                raise RuntimeError('The connection is already established. '
                                   'The listeners must be added before the connect.')
            super().set_listener(name, lstnr)

    # pylint: disable=arguments-differ
    def connect(self, username=None, passcode=None, wait=False, headers=None,
                connected_attempt=500, connected_delay=0.01, **keyword_headers):
        """
            Connect to the stomp server.
            wait==True will wait for the connected frame.
            Raises a StompConnectionTimeout if the "connected" frame is not received within the user timeout.
            Raises a StompConnectionError if an error occurs during the connection process (ex: authentication error)
        """
        with self.lock:
            connected_listener = None
            if wait:
                connected_listener = WaitForConnectedListener()
                super().set_listener(INTERNAL_CONNECTED_LISTENER_NAME, connected_listener)
            if self.connected:
                raise RuntimeError('The connection is already established. Can only be called once.')
            self.transport.start()
            self.connected = True
            Protocol12.connect(self, username, passcode, wait, headers, **keyword_headers)
            # Wait for the connected frame
            if connected_listener:
                def connected_received():
                    if not connected_listener.is_connected():
                        raise StompConnectionTimeout('Connected frame not received within the provided timeout:'
                                                     f'delay: \'{connected_delay}\' attempt: \'{connected_attempt}\'')

                retry_call(connected_received, tries=connected_attempt, delay=connected_delay,
                           exceptions=StompConnectionTimeout)

    def disconnect(self, receipt=None, headers=None, **keyword_headers):
        Protocol12.disconnect(self, receipt, headers, **keyword_headers)
        self.transport.stop()
        self.connected = False
