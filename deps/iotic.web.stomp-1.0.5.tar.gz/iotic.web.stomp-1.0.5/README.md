Python Stomp Client Over Websocket
==================================


This code is an adapter to be able to use the [stomp.py](https://github.com/jasonrbriggs/stomp.py) Stomp Client over websocket.
The original module only handles the Stomp protocol (1.0, 1.1, 1.2) over raw socket.

This adapter code is a part of this git repository for now, but the aim will be to submit a PR or to fork `stomp.py` repository under Iotic Labs github when it will be ready.

# Example
[See QAPI How to: async search](../iotic.web.rest.client/doc/search/async.py)

# Disable ssl

```python
client = StompWSConnection12(HOST_URL)
client.set_ssl(verify=False)
```
