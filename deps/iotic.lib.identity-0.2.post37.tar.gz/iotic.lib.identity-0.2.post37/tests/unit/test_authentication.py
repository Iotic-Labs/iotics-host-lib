# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

# flake8: noqa: E501
# pylint: disable=invalid-name,line-too-long,no-self-use

from datetime import datetime
from os import environ
import json
from time import sleep

import jwt
import pytest

import requests_mock

from iotic.lib.identity import Authentication
from iotic.lib.identity import Document
from iotic.lib.identity import Identifier
from iotic.lib.identity.exceptions import DecodeError, InvalidSignatureError, ExpiredSignatureError, NotAllowed,\
    IdentityNotFound

from .conftest import vector_const

TV = vector_const()


class TestAuthentication:
    @pytest.fixture(autouse=True)
    def setup(self):
        environ['RESOLVER'] = 'mock://resolver'

    def test_challenge(self):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        proof = Document.new_proof(TV['ident']['user1']['id'].encode('ascii'), pk)
        tkn = Authentication.new_challenge_token(TV['ident']['agent1']['id_name'],
                                                 TV['ident']['user1']['id'],
                                                 proof, pk)
        assert len(tkn) > 69

        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.verify_challenge(tkn) is not None

    def test_deleg_to_self(self):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        dc = Document.verify_document(TV['ident']['agent1']['ddo'])
        agent_doc = dc.doc

        proof = Document.new_proof(TV['ident']['agent1']['id'].encode('ascii'), pk)
        deleg = Document.new_delegation('#deltoself', TV['ident']['agent1']['id'], proof)
        agent_doc.add_control_delegation(deleg)
        agent_ddo = Document.new_document_token(agent_doc, TV['resolver_aud'], TV['ident']['agent1']['id'], pk)

        tkn = Authentication.new_authentication_token(TV['ident']['agent1']['id_name'],
                                                      TV['ident']['agent1']['id'], 'audience.example.com', 123, pk)

        with requests_mock.Mocker() as m:
            result = json.dumps({'token': agent_ddo})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            with pytest.raises(ValueError):
                Authentication.verify_authentication(tkn)

    @pytest.mark.parametrize('invalid_duration', (-1, 0, Authentication.MAX_DURATION + 1))
    def test_invalid_token_duration(self, invalid_duration):
        with pytest.raises(ValueError, match='Duration'):
            Authentication.new_authentication_token('a', 'b', 'c', invalid_duration, None)

    @pytest.mark.parametrize('offset', (0, Authentication.DEFAULT_TOKEN_START_OFFSET_SECONDS, -60*60))
    def test_token_iat_offset(self, offset):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        now = datetime.now().timestamp()
        tkn = Authentication.new_authentication_token(TV['ident']['user1']['id'] + TV['agent_deleg'],
                                                      TV['ident']['user1']['id'],
                                                      'audience.example.com', 1, pk, start_offset=offset)

        decoded = jwt.decode(tkn, verify=False)
        # Time of token validity should be within one second of the current time, taking offset into account
        assert abs(now - decoded['iat']) + offset < 1

    def test_token_iat_offset_default(self):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        now = datetime.now().timestamp()
        tkn = Authentication.new_authentication_token(TV['ident']['user1']['id'] + TV['agent_deleg'],
                                                      TV['ident']['user1']['id'],
                                                      'audience.example.com', 1, pk)

        decoded = jwt.decode(tkn, verify=False)
        # Time of token validity should be within one second of the current time, taking offset into account
        assert abs(now - decoded['iat']) + Authentication.DEFAULT_TOKEN_START_OFFSET_SECONDS < 1

    def test_verify_auth_allowed_old(self):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        tkn = Authentication.new_authentication_token(TV['ident']['agent1']['id_name'],
                                                      TV['ident']['user1']['id'], 'audience.example.com', 123, pk)
        assert len(tkn) > 69

        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['user1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.verify_authentication(tkn) is not None

    def test_verify_auth_allowed_new(self):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        tkn = Authentication.new_authentication_token(TV['ident']['user1']['id'] + TV['agent_deleg'],
                                                      TV['ident']['user1']['id'],
                                                      'audience.example.com', 1, pk)
        assert len(tkn) > 69

        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['user1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            auth = Authentication.verify_authentication(tkn)
            assert auth['iss'] == TV['ident']['user1']['id'] + TV['agent_deleg']
            assert auth['sub'] == TV['ident']['user1']['id']
            assert auth['aud'] == 'audience.example.com'

            sleep(2)
            with pytest.raises(ExpiredSignatureError):
                Authentication.verify_authentication(tkn)

            with pytest.raises(InvalidSignatureError):
                Authentication.verify_authentication(tkn + b'x')

    def test_verify_auth_not_allowed(self):
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        tkn = Authentication.new_authentication_token(TV['ident']['agent1']['id'] + '#agent-0', TV['ident']['user1']['id'],
                                                      'audience.example.com', 1, pk)
        assert len(tkn) > 69

        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['user1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            with pytest.raises(NotAllowed):
                Authentication.verify_authentication(tkn)

    def test_verify_auth_malformed(self):
        with pytest.raises(DecodeError):
            Authentication.verify_authentication('thisisamalformedtoken')

    def test_check_allowed_no_deleg_not_allowed(self):
        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['user1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.check_allowed(TV['ident']['user1']['id'] + TV['agent_deleg'],
                                                TV['ident']['user1']['id'], False) is False

    def test_check_allowed_user_agent_allowed(self):
        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['user1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.check_allowed(TV['ident']['user1']['id'] + TV['agent_deleg'],
                                                TV['ident']['user1']['id'], False) is True

    def test_check_allowed_agent_user_allowed(self):
        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['user1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.check_allowed(TV['ident']['agent1']['id'] + '#agent-0', TV['ident']['user1']['id'], False) is True

    def test_check_allowed_agent_twin_allowed(self):
        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['twin1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['twin1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.check_allowed(TV['ident']['agent1']['id_name'], TV['ident']['twin1']['id'], False) is True

    def test_check_allowed_user_twin_not_allowed(self):
        # Note: NOT Allowed! AEN-1016 added the check_allowed function to make authentication more permissive
        # But this relationship is User -> Agent <- Twin with authentication User -> Twin which is not allowed
        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['twin1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['twin1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['user1']['ddo_deleg']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Authentication.check_allowed(TV['ident']['user1']['id'] + TV['agent_deleg'],
                                                TV['ident']['twin1']['id'], False) is False

    def test_check_allowed_not_existing_identity(self):
        not_existing_identity = 'did:iotics:iot' + 'A' * 33
        with requests_mock.Mocker() as m:
            m.get(f'mock://resolver/1.0/discover/{not_existing_identity}', json={'error': 'Not found'}, status_code=404)

            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            with pytest.raises(IdentityNotFound):
                Authentication.check_allowed(TV['ident']['agent1']['id_name'], not_existing_identity, False)
