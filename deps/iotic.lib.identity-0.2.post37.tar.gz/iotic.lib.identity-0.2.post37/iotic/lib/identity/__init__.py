# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from .client import IdentityClient  # noqa:F401
from .metrics import register_metrics  # noqa:F401
from . import identifier as Identifier  # noqa:F401
from . import document as Document  # noqa:F401
from . import authentication as Authentication  # noqa:F401
from . import exceptions  # noqa:F401

# Previously imported from document module
Resolver = None  # pylint: disable=invalid-name


def setup_backcompat():
    # pylint: disable=import-outside-toplevel
    # The following imports are for backwards compatibility only
    from .resolver import RESOLVER_ENV
    from .compat import CompatResolver, find_issuer_by_doc, find_issuer_by_id, verify_document, check_allowed, \
        verify_authentication, verify_challenge

    Document.Resolver = CompatResolver
    Document.RESOLVER_ENV = RESOLVER_ENV
    Document.find_issuer_by_doc = find_issuer_by_doc
    Document.find_issuer_by_id = find_issuer_by_id
    Document.verify_document = verify_document

    global Resolver  # pylint: disable=invalid-name, global-statement
    Resolver = CompatResolver

    Authentication.check_allowed = check_allowed
    Authentication.verify_authentication = verify_authentication
    Authentication.verify_challenge = verify_challenge


setup_backcompat()
