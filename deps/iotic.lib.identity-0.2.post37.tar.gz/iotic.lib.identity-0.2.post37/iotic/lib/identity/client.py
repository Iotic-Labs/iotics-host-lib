# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import jwt

from iotic.lib.identity.common import verify_token
from iotic.lib.identity.exceptions import DecodeError, NotAllowed
from iotic.lib.identity import document as Document
from iotic.lib.identity import identifier as Identifier
from iotic.lib.identity.resolver import ResolverClient, HttpResolverClient


class IdentityClient:
    """Provides SDK functionality which involves interactions with a resolver."""

    def __init__(self, resolverClient: ResolverClient = None):
        """Construct a new identity client. If resolverClient is not specified, the 'RESOLVER' environment variable
        is expected to contain the location of an http-reachable resolver server."""
        if resolverClient is None:
            self.__resolverClient = HttpResolverClient.from_env()
        elif not isinstance(resolverClient, ResolverClient):
            raise TypeError('resolverClient must implement ResolverClient')
        else:
            self.__resolverClient = resolverClient

    def verify_challenge(self, tkn: str) -> dict:
        """verify_challenge: Verify challenge token"""
        unverified = verify_token(tkn, verify=False)
        for field in ('iss', 'aud'):
            if field not in unverified:
                raise DecodeError(f'Token missing {field}')

        iss_key = self.find_issuer_by_id(unverified['iss'], unverified['iss'], True)
        if iss_key is None:
            return None

        verified = verify_token(tkn, iss_key.public_key, unverified['aud'])

        return {'iss': verified['iss'],
                'aud': verified['aud'],
                'proof': verified['proof']}

    def verify_authentication(self, tkn: str) -> dict:
        """verify_authentication: Verify authentication token"""
        unverified = verify_token(tkn, verify=False)
        for field in ('iss', 'sub', 'aud', 'iat', 'exp'):
            if field not in unverified:
                raise DecodeError(f'Token missing {field}')

        iss_key = self.find_issuer_by_id(unverified['iss'], unverified['iss'], False, full=False)
        if iss_key is None:
            return None

        verified = verify_token(tkn, iss_key.public_key, unverified['aud'])

        if not self.check_allowed(verified['iss'], verified['sub'], control_only=False, full=False):
            raise NotAllowed('Not allowed')

        return {'iss': verified['iss'],
                'sub': verified['sub'],
                'aud': verified['aud'],
                'iat': verified['iat'],
                'exp': verified['exp']}

    def check_allowed(self, iss: str, sub: str, control_only: bool = True, full: bool = True) -> bool:
        """check_allowed: Fetch the subject document and check issuer is allowed to auth or control
        This is similar to find_issuer but does not return public key.
        This checks that issuer is allowed to work on behalf of issuer according to Subject DID Doc.
        It should be called AFTER checking authentication (eg after find_issuer_ / verify_token)
        This is implemented in the SDK to save users like iotic-web/rest from implementing this logic.

        Warning: This is not a security function! No cryptographic proof is required for check_allowed!

        iss: Issuer ID who made the token (eg Agent DID # Agent Key)
        sub: Subject ID who iss wants to control/auth. (Subject DID)
        control_only: True for control, False for Auth
        """
        iss_name = Identifier.split_name_off_id(iss)
        if iss_name is None:
            raise ValueError('Issuer must have #name')

        sub_doc = self.discover(sub, full)
        iss_doc = self.discover(iss, full)

        if iss_doc.revoked or sub_doc.revoked:
            return False

        if sub_doc.controller is not None:
            if Identifier.compare_identifier_only(iss, sub_doc.controller):
                return self.check_allowed(iss, sub_doc.controller, control_only=control_only, full=full)

        if Identifier.compare_identifier_only(iss, sub):
            keylist = sub_doc.public_keys
            if not control_only:
                keylist = keylist + sub_doc.authentication_keys

            for k in keylist:
                if iss_name == k.id:
                    return True

        deleglist = sub_doc.delegate_control
        if not control_only:
            deleglist = deleglist + sub_doc.delegate_authentication

        for k in deleglist:
            if k.revoked:
                continue
            if Identifier.compare_identifier_only(iss, sub) and iss_name == k.id:
                return True
            if Identifier.compare_identifier_only(iss, k.controller):
                return True

        return False

    def find_issuer_by_doc(
            self, doc: Document.DIDDocument, iss: str, control_only: bool, full: bool = True, depth: int = 0
    ) -> Document.IssuerKey:
        """find_issuer_by_doc: Find if this issuer (iss) given the document"""
        depth = depth + 1
        if depth > Document.DOCUMENT_MAX_FINDISSUER_DEPTH:
            raise ValueError('Max find issuer depth exceeded')

        if not self.validate_document(doc, full=full):
            raise ValueError('find_issuer document not valid')

        iss_name = Identifier.split_name_off_id(iss)
        if iss_name is None:
            raise ValueError('Issuer must have #name')

        # Check if this document is the issuer!
        if Identifier.compare_identifier_only(doc.id, iss):

            keylist = doc.public_keys
            if not control_only:
                keylist = keylist + doc.authentication_keys

            for k in keylist:
                if k.id == iss_name:
                    return Document.IssuerKey(k.public_base58, iss, k.revoked)

            deleglist = doc.delegate_control
            if not control_only:
                deleglist = deleglist + doc.delegate_authentication

            for k in deleglist:
                if k.id == iss_name:
                    return self.find_issuer_by_id(k.controller, k.controller, control_only, full=full, depth=depth)

        else:
            if doc.controller is not None:
                if Identifier.compare_identifier_only(doc.controller, iss):
                    return self.find_issuer_by_id(doc.controller, iss, control_only, full=full, depth=depth)

            for k in doc.delegate_authentication + doc.delegate_control:
                if Identifier.compare_identifier_only(k.controller, iss):
                    return self.find_issuer_by_id(k.controller, iss, control_only, full=full, depth=depth)

        # Issuer Key not found
        return None

    def find_issuer_by_id(
            self, did: str, iss: str, control_only: bool, full: bool = True, depth: int = 0
    ) -> Document.IssuerKey:
        """find_issuer_by_id: Fetch DDO by ID and call find_issuer_by_doc"""
        doc = self.discover(did, full=full)
        return self.find_issuer_by_doc(doc, iss, control_only, full=full, depth=depth)

    def validate_document(self, doc: Document.DIDDocument, full: bool = True) -> Document.DIDDocumentValid:
        return doc.validate(full=full, discover_func=self.discover)

    def verify_document(self, tkn: str, full: bool = True) -> Document.DIDDocumentClaims:
        """verify_document: Take a DDO token string and return DIDDocument instance or raise"""
        # Build doc from decoded JWT
        unverified = jwt.decode(tkn, verify=False)
        for field in ['iss', 'aud', 'doc']:
            if field not in unverified:
                raise DecodeError(f'Token missing {field}')

        key_id = Document.KeyID(unverified['doc']['publicKey'][0]['id'], unverified['doc']['publicKey'][0]['type'],
                                unverified['doc']['publicKey'][0]['publicKeyBase58'])
        doc = Document.DIDDocument(Identifier.DIDType(unverified['doc']['ioticsDIDType']), unverified['doc']['id'],
                                   unverified['doc']['proof'], key_id)
        doc.spec_version = unverified['doc']['ioticsSpecVersion']

        doc.update_time = unverified['doc']['updateTime']

        if 'revoked' in unverified['doc']:
            doc.revoked = unverified['doc']['revoked']
        if 'controller' in unverified['doc']:
            doc.controller = unverified['doc']['controller']
        if 'creator' in unverified['doc']:
            doc.creator = unverified['doc']['creator']

        for k in unverified['doc']['publicKey'][1:]:
            doc.add_public_key(Document.KeyID(k['id'], k['type'], k['publicKeyBase58']))
        if 'authentication' in unverified['doc']:
            for k in unverified['doc']['authentication']:
                doc.add_authentication_key(Document.KeyID(k['id'], k['type'], k['publicKeyBase58']))

        for j in ['delegateControl', 'delegateAuthentication']:
            if j not in unverified['doc']:
                continue
            for k in unverified['doc'][j]:
                revoked = None
                if 'revoked' in k:
                    revoked = k['revoked']

                # makes dataclass (no client/resolver usage)
                deleg = Document.Delegation(k['id'], k['controller'], k['proof'], revoked=revoked)
                if j == 'delegateControl':
                    # self.delegationHandler.addControlDeleg(doc, client, ...)
                    doc.add_control_delegation(deleg)
                else:
                    doc.add_authentication_delegation(deleg)

        if not self.validate_document(doc, full=full):
            return None  # TODO: raise ?

        iss_key = self.find_issuer_by_doc(doc, unverified['iss'], True, full)
        if iss_key is None:
            return None  # TODO: raise ?

        verify_token(tkn, iss_key.public_key, unverified['aud'])

        return Document.DIDDocumentClaims(iss=unverified['iss'],
                                          aud=unverified['aud'],
                                          doc=doc)

    def discover(self, did: str, full: bool = True) -> Document.DIDDocument:
        """discover: Calls the resolver and returns DIDDocument instance or None"""
        did_id = did.split('#')[0]
        Identifier.validate_identifier(did_id)
        tkn = self.__resolverClient.get_token(did_id)
        # Both decodes and verifies the raw document
        claims = self.verify_document(tkn, full=full)
        if claims is None:
            return None
        return claims.doc

    def register(self, tkn: str):
        """register: Register a DDO with the resolver"""
        self.__resolverClient.register_token(tkn)
