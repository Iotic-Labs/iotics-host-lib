# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

# This module provides backwards compatibility for functions which previously implicitly read resolver configuration
# from the environment.

# pylint: disable=invalid-name

from functools import wraps
from warnings import warn

from iotic.lib.identity.client import IdentityClient


def _compat_warn(func):

    @wraps(func)
    def wrapped(*args, **kwargs):
        warn(f'{func.__name__} is deprecated. Please instead use IdentityClient.{func.__name__}', DeprecationWarning)
        # Simulate old behaviour:
        # 1) Latest value of environment variable is reflected in each new call
        # 2) An exception is raised regarding lack of env var at time of required call
        client = IdentityClient()
        return getattr(client, func.__name__)(*args, **kwargs)

    return wrapped


# Static functions which were previously available
verify_challenge = _compat_warn(IdentityClient.verify_challenge)
verify_authentication = _compat_warn(IdentityClient.verify_authentication)
check_allowed = _compat_warn(IdentityClient.check_allowed)
find_issuer_by_doc = _compat_warn(IdentityClient.find_issuer_by_doc)
find_issuer_by_id = _compat_warn(IdentityClient.find_issuer_by_id)
verify_document = _compat_warn(IdentityClient.verify_document)


# Previously defined in document module
class CompatResolver:
    """Deprecated: Use methods available in IdentityClient instead."""

    discover = _compat_warn(IdentityClient.discover)
    register = _compat_warn(IdentityClient.register)
