# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import base64
import jwt

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

from iotic.lib.identity import identifier
from iotic.lib.identity.exceptions import InvalidSignatureError, ExpiredSignatureError, DecodeError


def verify_token(tkn: str, iss='', aud='', verify=True) -> dict:
    """verify_token: Helper to verify JWT token or raise exception"""
    try:
        return jwt.decode(tkn, iss, audience=aud, algorithms=['ES256'], verify=verify)
    except jwt.exceptions.InvalidSignatureError as exc:
        raise InvalidSignatureError(exc)
    except jwt.exceptions.ExpiredSignatureError as exc:
        raise ExpiredSignatureError(exc)
    except Exception as exc:
        raise DecodeError(exc)


def verify_proof(proof: str, content: bytes, public_key_base58: str) -> bool:
    """verify_proof: Takes base64 encoded proof, content bytes and public key base58 to verify proof signature
    returns true/false
    """
    pub_key = identifier.public_base58_to_ECDSA(public_key_base58)
    signature = base64.b64decode(proof)
    try:
        pub_key.verify(signature, content, ec.ECDSA(hashes.SHA256()))
    except InvalidSignature:
        return False
    return True
