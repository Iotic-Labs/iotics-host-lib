# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.


class IdentityBaseException(Exception):
    """IdentityBaseException: Base of all iotic.lib.identity exceptions"""


class InvalidSignatureError(IdentityBaseException):
    """InvalidSignatureError: Raised when unable to verify signature on JWT token"""


class ExpiredSignatureError(IdentityBaseException):
    """ExpiredSignatureError: Raised when token is expired"""


class DecodeError(IdentityBaseException):
    """DecodeError: Raised when token cannot be decoded"""


class NotAllowed(IdentityBaseException):
    """NotAllowed: Raised for valid auth' tokens that are not allowed because eg no delegation"""


class IdentityNotFound(IdentityBaseException):
    """IdentityNotfound: Raised when resolver cannot find the identity"""


class InvalidConfiguration(IdentityBaseException):
    """InvalidConfiguration: Raised when configuration passed to the identity client is not valid."""


class ResolverError(IdentityBaseException):
    """ResolverError: Base of errors for failure to perform an operation against the resolver."""


class CommunicationError(ResolverError):
    """CommunicationError: Communication with the resolver failed during an operation"""


class CommunicationTimeoutError(CommunicationError):
    """TimeoutError: Communication with the resolver timed out during an operation"""


class ServerError(ResolverError):
    """ServerError: An operation against the resolver failed due to a server-side issue"""
