# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from typing import Callable

from iotic.lib.identity import identifier as Identifier
from iotic.lib.identity.common import verify_proof


class Delegation:
    """Delegation: """

    def __init__(self, name: str, controller: str, proof: str, revoked: False):
        Identifier.validate_key_name(name)
        Identifier.validate_identifier(controller)

        self.__id = name
        self.__controller = controller
        self.__proof = proof
        self.__revoked = bool(revoked)

    def __dict__(self):
        ret = {'id': self.__id, 'controller': self.__controller, 'proof': self.__proof}
        if self.__revoked is not None:
            ret['revoked'] = self.__revoked
        return ret

    # Note: discover_func must have same signature as IdentityClient.discover
    def validate_full(self, parent_id, discover_func: Callable, controller_doc=None):
        """validate: """
        if parent_id is not None:
            if Identifier.compare_identifier_only(parent_id, self.__controller):
                raise ValueError('Delegate to self not allowed')

            if controller_doc is None:
                controller_doc = discover_func(self.__controller, full=False)

            valid_proof = False
            for k in controller_doc.public_keys:
                if verify_proof(self.__proof, parent_id.encode('ascii'), k.public_base58):
                    valid_proof = True
                    break
            # todo: check delegate_control keys
            if not valid_proof:
                raise ValueError('Delegation proof not valid')

        return True

    @property
    def id(self):
        return self.__id

    @property
    def controller(self) -> str:
        return self.__controller

    @property
    def revoked(self) -> bool:
        return self.__revoked

    @revoked.setter
    def revoked(self, val: bool):
        self.__revoked = bool(val)
