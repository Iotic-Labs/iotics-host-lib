# pylint: disable=invalid-name,global-statement,redefined-outer-name

import os
import json
from time import time
import logging

import requests_mock

import pytest
from pytest_bdd import given, parsers, scenario, then, when

from iotic.lib.identity import Identifier
from iotic.lib.identity import Document
from iotic.lib.identity import Authentication
from iotic.lib.identity.exceptions import NotAllowed


FEATURES = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'features')

ANOTHER_NAME = '#another-1'

os.environ['RESOLVER'] = 'mock://resolver'


# Globals to pass results between given/then & when
passID = None
passPub = None
passSeed = None
passMethod = None
passMnemonic = None
passPurpose = None
passPubB58 = None
passPriv = None
passMaster = None
passMasterP = None
passDoc = None
passDocTkn = None
passAnotherPK = None
passAuthTkn = None


@pytest.fixture
def vectors():
    try:
        file_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test_vectors.json')
        with open(file_path) as fpr:
            return json.load(fpr)
    except (json.JSONDecodeError, TypeError) as err:
        logging.error('Invalid json spec from %s', file_path)
        raise err
    except OSError as err:
        logging.error('Can not load file %s', file_path)
        raise err


# GIVEN

@given(parsers.parse('the public key of "<entity>" from the fixture'))
def given_public_key(entity, vectors):
    global passPub
    passPub = vectors['ident'][entity]['pub']


@given(parsers.parse('the mnemonic of "<entity>" from the fixture'))
def given_mnemonic(entity, vectors):
    global passMnemonic
    global passMethod
    passMnemonic = vectors['ident'][entity]['mnemonic']
    passMethod = Identifier.SeedMethod(vectors['ident'][entity]['seed_method'])


@given(parsers.parse('the seed of "<entity>" and "<purpose>" from the fixture'))
def given_seed(entity, purpose, vectors):
    global passSeed
    global passMethod
    global passPurpose
    passSeed = vectors['ident'][entity]['seed']
    passMethod = Identifier.SeedMethod(vectors['ident'][entity]['seed_method'])
    passPurpose = purpose


@given("agent1 from the fixture")
def given_agent1(vectors):
    given_seed('agent1', 'agent', vectors)
    when_i_make_a_private_key()
    when_i_make_a_new_document()


# WHEN

@when('I make an identifier')
def when_i_make_an_identifier():
    global passID
    passID = Identifier.make_identifier(passPub)


@when('I make a seed from mnemonic')
def when_i_make_a_seed_from_mnemonic():
    global passMnemonic
    global passSeed
    passSeed = Identifier.mnemonic_to_seed(passMnemonic)


@when('I make a private key')
def when_i_make_a_private_key():
    global passSeed
    global passPriv
    global passPurpose
    global passMethod
    mad = Identifier.seed_to_master(passSeed, method=passMethod)
    passPriv = Identifier.new_private_hex_from_path_str(mad, passPurpose, '00')


@when('I make a public key')
def when_i_make_a_public_key():
    global passPriv
    global passPub
    global passPubB58
    global passID
    pk = Identifier.private_hex_to_ECDSA(passPriv)
    pu = Identifier.private_ECDSA_to_public_ECDSA(pk)
    passPub = Identifier.public_ECDSA_to_bytes(pu).hex()
    passPubB58 = Identifier.public_ECDSA_to_base58(pu)
    passID = Identifier.make_identifier(passPub)


@when('I make a master data')
def when_i_make_a_master_data(vectors):
    global passSeed
    global passMethod
    global passMaster
    global passMasterP
    passMaster = Identifier.seed_to_master(passSeed, method=passMethod).hex()
    passMasterP = Identifier.seed_to_master(passSeed,
                                            password=vectors['password'].encode('ascii'),
                                            method=passMethod).hex()


@when('I make a new document')
def when_i_make_a_new_document():
    global passPurpose
    global passPriv
    global passDoc
    did_type = Identifier.DIDType(passPurpose)
    pk = Identifier.private_hex_to_ECDSA(passPriv)
    name = f'#{passPurpose}-0'
    passDoc = Document.new_did_document(did_type, pk, name)


@when('I set the creator field')
def i_set_the_creator_field(vectors):
    global passDoc
    global passDocTkn
    global passPriv

    pk = Identifier.private_hex_to_ECDSA(passPriv)

    passDoc.creator = vectors['ident']["user0"]['id']

    passDocTkn = Document.new_document_token(passDoc,
                                             vectors['resolver_aud'],
                                             passDoc.id + passDoc.public_keys[0].id,
                                             pk)


@when('I set the revoked field')
def i_set_the_revoked_field(vectors):
    global passDoc
    global passDocTkn
    global passPriv

    pk = Identifier.private_hex_to_ECDSA(passPriv)

    passDoc.revoked = True

    passDocTkn = Document.new_document_token(passDoc,
                                             vectors['resolver_aud'],
                                             passDoc.id + passDoc.public_keys[0].id, pk)


@when('I make an updated document with initial')
def when_i_make_an_updated_document_with_initial(vectors):
    # Note: This takes passDoc and updates the update_time and produces passDocTkn
    global passPriv
    global passDoc
    global passDocTkn
    pk = Identifier.private_hex_to_ECDSA(passPriv)
    iss = passDoc.id + passDoc.public_keys[0].id
    passDoc.update_time = time() * 1000
    passDocTkn = Document.new_document_token(passDoc, vectors['resolver_aud'], iss, pk)


@when('I make an updated document with new')
def when_i_make_an_updated_document_with_new(vectors):
    # Note: This takes passDoc and updates the update_time and produces passDocTkn
    global passPriv
    global passDoc
    global passDocTkn
    global passAnotherPK

    iss = passDoc.id + ANOTHER_NAME
    passDoc.update_time = time() * 1000
    passDocTkn = Document.new_document_token(passDoc, vectors['resolver_aud'], iss, passAnotherPK)


@when('I make an updated document with delegate')
def when_i_make_an_updated_document_with_delegate(vectors):
    global passDoc
    global passDocTkn

    iss = vectors['ident']['controller']['id_name']
    pk = Identifier.private_hex_to_ECDSA(vectors['ident']['controller']['priv'])
    passDoc.update_time = time() * 1000
    passDocTkn = Document.new_document_token(passDoc, vectors['resolver_aud'], iss, pk)


@when('I make an updated document with controller')
def when_i_make_an_updated_document_with_controller(vectors):
    # Note: This takes passDoc and updates the update_time and produces passDocTkn
    global passDoc
    global passDocTkn

    pk = Identifier.private_hex_to_ECDSA(vectors['ident']['controller']['priv'])
    iss = vectors['ident']['controller']['id_name']

    passDoc.update_time = time() * 1000
    passDocTkn = Document.new_document_token(passDoc, vectors['resolver_aud'], iss, pk)


@when('I add a new public key')
def when_i_add_a_new_public_key(vectors):
    global passPriv
    global passDoc
    global passDocTkn
    global passAnotherPK

    mad = Identifier.seed_to_master(passSeed, method=passMethod)
    new_pk = Identifier.new_private_hex_from_path_str(mad, passPurpose, ANOTHER_NAME)
    passAnotherPK = private_ecdsa = Identifier.private_hex_to_ECDSA(new_pk)
    public_ecdsa = Identifier.private_ECDSA_to_public_ECDSA(private_ecdsa)
    public_base58 = Identifier.public_ECDSA_to_base58(public_ecdsa)
    passDoc.add_public_key(Document.new_keyid_publickey(ANOTHER_NAME, public_base58))

    pk = Identifier.private_hex_to_ECDSA(passPriv)
    iss = passDoc.id + passDoc.public_keys[0].id
    passDoc.update_time = time() * 1000
    passDocTkn = Document.new_document_token(passDoc, vectors['resolver_aud'], iss, pk)


@when('I remove the initial key')
def when_i_remove_the_initial_key():
    global passDoc

    passDoc.remove_public_key(passDoc.public_keys[0].id)


@when('I revoke the initial key')
def when_i_revoke_the_initial_key():
    global passDoc

    passDoc.public_keys[0].revoked = True


@when('I revoke the initial key from agent1')
def when_i_revoke_the_initial_key_from_agent1(vectors):
    when_i_make_a_private_key()
    when_i_make_a_new_document()
    when_i_add_a_new_public_key(vectors)
    when_i_revoke_the_initial_key()
    when_i_make_an_updated_document_with_new(vectors)
    when_i_make_an_auth_token_for_agent1_user1(vectors)


@when('I set a controller')
def when_i_set_a_controller(vectors):
    global passDoc

    passDoc.controller = vectors['ident']['controller']['id']


@when('I set a controller on agent1')
def when_i_set_a_controller_on_agent1(vectors):
    when_i_make_a_private_key()
    when_i_make_a_new_document()
    when_i_set_a_controller(vectors)
    when_i_make_an_updated_document_with_initial(vectors)
    when_i_make_an_auth_token_for_agent1_user1(vectors)


@when('I add a delegate control')
def when_i_add_a_delegate_control(vectors):
    global passDoc

    pk = Identifier.private_hex_to_ECDSA(vectors['ident']['controller']['priv'])
    iss = vectors['ident']['controller']['id_name']
    proof = Document.new_proof(passDoc.id.encode('ascii'), pk)

    passDoc.add_control_delegation(Document.new_delegation('#cont', iss, proof))


@when('I add a delegate control on agent1')
def when_i_add_a_delegate_control_on_agent1(vectors):
    when_i_make_a_private_key()
    when_i_make_a_new_document()
    when_i_add_a_delegate_control(vectors)
    when_i_make_an_updated_document_with_new(vectors)
    when_i_make_an_auth_token_for_agent1_user1(vectors)


@when('I add a revoked delegate control')
def when_i_add_a_revoked_delegate_control(vectors):
    global passDoc

    pk = Identifier.private_hex_to_ECDSA(vectors['ident']['controller']['priv'])
    iss = vectors['ident']['controller']['id_name']
    proof = Document.new_proof(passDoc.id.encode('ascii'), pk)

    passDoc.add_control_delegation(Document.new_delegation('#cont', iss, proof, revoked=True))


@when('I revoke a delegate control')
def when_i_revoke_a_delegate_control():
    global passDoc

    passDoc.delegate_control[0].revoked = True


@when('I make an auth token for agent1 -> user1')
def when_i_make_an_auth_token_for_agent1_user1(vectors):
    global passAuthTkn

    private_key_ecdsa = Identifier.private_hex_to_ECDSA(vectors['ident']['agent1']['priv'])
    iss = vectors['ident']['agent1']['id_name']

    passAuthTkn = Authentication.new_authentication_token(iss,
                                                          vectors['ident']['user1']['id'],
                                                          vectors['auth_aud'],
                                                          123,
                                                          private_key_ecdsa)


@when('I make an auth token for agent1 -> user0')
def when_i_make_an_auth_token_for_agent1_user0(vectors):
    global passAuthTkn

    private_key_ecdsa = Identifier.private_hex_to_ECDSA(vectors['ident']['agent1']['priv'])
    iss = vectors['ident']['agent1']['id_name']

    passAuthTkn = Authentication.new_authentication_token(iss,
                                                          vectors['ident']['user0']['id'],
                                                          vectors['auth_aud'],
                                                          123,
                                                          private_key_ecdsa)


@when('I make an auth token for agent1 using delegation -> user1')
def when_i_make_an_auth_token_for_agent1_using_delegation_user1(vectors):
    global passAuthTkn

    private_key_ecdsa = Identifier.private_hex_to_ECDSA(vectors['ident']['controller']['priv'])
    iss = vectors['ident']['controller']['id_name']

    passAuthTkn = Authentication.new_authentication_token(iss,
                                                          vectors['ident']['user1']['id'],
                                                          vectors['auth_aud'],
                                                          123,
                                                          private_key_ecdsa)


@when('I make an auth token for agent1 using controller -> user1')
def when_i_make_an_auth_token_for_agent1_using_controller_user1(vectors):
    global passAuthTkn

    private_key_ecdsa = Identifier.private_hex_to_ECDSA(vectors['ident']['controller']['priv'])
    iss = vectors['ident']['controller']['id_name']

    passAuthTkn = Authentication.new_authentication_token(iss,
                                                          vectors['ident']['user1']['id'],
                                                          vectors['auth_aud'],
                                                          123,
                                                          private_key_ecdsa)


# THEN

@then(parsers.parse('the result matches the ID of "<entity>" from the fixture'))
def then_the_result_matches_the_id(entity, vectors):
    global passID
    assert passID == vectors['ident'][entity]['id']


@then('the identifier is valid')
def then_the_identifier_is_valid():
    global passID
    assert Identifier.validate_identifier(passID)


@then(parsers.parse('the result matches the private of "<entity>" from the fixture'))
def then_the_result_matches_the_private(entity, vectors):
    global passPriv
    assert passPriv == vectors['ident'][entity]['priv']


@then(parsers.parse('the result matches the public of "<entity>" from the fixture'))
def then_the_result_matches_the_public(entity, vectors):
    global passPub
    global passPubB58
    global passID
    assert passPub == vectors['ident'][entity]['pub']
    assert passPubB58 == vectors['ident'][entity]['pub_base58']
    assert passID == vectors['ident'][entity]['id']
    assert Identifier.compare_identifier_only(passID, vectors['ident'][entity]['id'])


@then(parsers.parse('the result matches the seed of "<entity>"'))
def then_the_result_matches_the_seed(entity, vectors):
    global passMnemonic
    global passSeed
    assert passSeed == vectors['ident'][entity]['seed']
    assert Identifier.seed_to_mnemonic(passSeed) == passMnemonic


@then(parsers.parse('the result matches the master data of "<entity>"'))
def then_the_result_matches_the_master(entity, vectors):
    global passMaster
    global passMasterP
    assert passMaster == vectors['ident'][entity]['master_hex']
    assert passMasterP == vectors['ident'][entity]['master_hex_p']


def check_keys_match(keys1: list, keys2: list):
    assert len(keys1) == len(keys2)
    for key1 in keys1:
        match = False
        for key2 in keys2:
            if key1.id == key2.id:
                assert key1.public_base58 == key2.public_base58
                assert key1.revoked == key2.revoked
                assert key1.type == key2.type
                match = True
                break
        assert match, 'keys do not match'


def check_delegates_match(dels1: list, dels2: list):
    assert len(dels1) == len(dels2)
    for del1 in dels1:
        match = False
        for del2 in dels2:
            if del1.id == del2.id:
                assert del1.controller == del2.controller
                assert del1.revoked == del2.revoked

                assert del2.validate()
                match = True
                break
        assert match, 'delegates do not match'


@then(parsers.parse('the result matches the ddo of "<entity>" from the fixture'))
def then_the_result_matches_the_ddo(entity, vectors):
    global passDoc
    assert passDoc.id == vectors['ident'][entity]['id']
    dc = Document.verify_document(vectors['ident'][entity]['ddo'])
    doc = dc.doc
    assert doc.id == passDoc.id
    assert doc.did_type == passDoc.did_type
    # update_time won't be the same
    # proof won't be the same, but can be verified

    v = passDoc.validate()
    assert v.valid

    assert len(doc.public_keys) > 0

    check_keys_match(doc.public_keys, passDoc.public_keys)

    check_keys_match(doc.authentication_keys, passDoc.authentication_keys)

    check_delegates_match(doc.delegate_authentication, passDoc.delegate_authentication)

    check_delegates_match(doc.delegate_control, passDoc.delegate_control)

    # check metadata
    assert doc.metadata.label == passDoc.metadata.label
    assert doc.metadata.comment == passDoc.metadata.comment
    assert doc.metadata.url == passDoc.metadata.url


@then('the resulting document has the correct creator field')
def the_resulting_document_has_the_correct_creator_field(vectors):
    """the resulting document has the correct creator field."""
    global passDocTkn
    dc = Document.verify_document(passDocTkn)
    doc = dc.doc

    assert doc.creator == vectors['ident']['user0']['id']


@then('the resulting document has revoked set to true')
def the_resulting_document_has_revoked_set_to_true():
    """the resulting document has revoked set to true."""
    global passDocTkn
    dc = Document.verify_document(passDocTkn)
    doc = dc.doc

    assert doc.revoked


@then('the resulting document is valid')
def then_the_resulting_document_is_valid(vectors):
    global passDocTkn

    with requests_mock.Mocker() as m:
        result = json.dumps({'token': vectors['ident']['controller']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['controller']['id'], text=result)

        dc = Document.verify_document(passDocTkn)
        rDoc = dc.doc
        assert rDoc
        assert rDoc.validate()


@then('the auth token is allowed')
def then_the_auth_token_is_allowed(vectors):
    global passAuthTkn

    with requests_mock.Mocker() as m:
        result = json.dumps({'token': vectors['ident']['agent1']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['agent1']['id'], text=result)

        result = json.dumps({'token': vectors['ident']['user1']['ddo_deleg']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['user1']['id'], text=result)

        assert Authentication.verify_authentication(passAuthTkn)


@then('the auth token is allowed using delegation')
def then_the_auth_token_is_allowed_using_delegation(vectors):
    global passAuthTkn
    global passDocTkn

    with requests_mock.Mocker() as m:
        result = json.dumps({'token': passDocTkn})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['agent1']['id'], text=result)

        result = json.dumps({'token': vectors['ident']['user1']['ddo_deleg']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['user1']['id'], text=result)

        result = json.dumps({'token': vectors['ident']['controller']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['controller']['id'], text=result)

        assert Authentication.verify_authentication(passAuthTkn)


@then('the auth token is not allowed')
def then_the_auth_token_is_not_allowed(vectors):
    global passAuthTkn

    with requests_mock.Mocker() as m:
        result = json.dumps({'token': vectors['ident']['agent1']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['agent1']['id'], text=result)

        result = json.dumps({'token': vectors['ident']['user0']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['user0']['id'], text=result)

        # todo: not sure why user1 is needed? Remove after perf fix is in?
        result = json.dumps({'token': vectors['ident']['user1']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['user1']['id'], text=result)
        result = json.dumps({'token': vectors['ident']['controller']['ddo']})
        m.get('mock://resolver/1.0/discover/' + vectors['ident']['controller']['id'], text=result)

        with pytest.raises(NotAllowed):
            Authentication.verify_authentication(passAuthTkn)


# Scenario

@scenario('identifier.feature', 'Make an identifier from a public key (DER uncompressed)', features_base_dir=FEATURES)
def test_id_from_public_der():
    pass


@scenario('identifier.feature', 'Make a seed from mnemonic', features_base_dir=FEATURES)
def test_make_seed_from_mnemonic():
    pass


@scenario('identifier.feature', 'Make a private key', features_base_dir=FEATURES)
def test_make_private_key():
    pass


@scenario('document.feature', 'Make a new document', features_base_dir=FEATURES)
def test_doc_new():
    pass


@scenario('document.feature', 'Update a document with initial key', features_base_dir=FEATURES)
def test_doc_update_initial():
    pass


@scenario('document.feature', 'Update a document with not initial key', features_base_dir=FEATURES)
def test_doc_update_not_initial():
    pass


@scenario('document.feature', 'Update a document with initial key missing', features_base_dir=FEATURES)
def test_doc_update_no_initial():
    pass


@scenario('document.feature', 'Update a document with delegate control', features_base_dir=FEATURES)
def test_doc_update_using_delegation():
    pass


@scenario('document.feature', 'Update a document with revoked delegation', features_base_dir=FEATURES)
def test_doc_update_using_revoked_delegation():
    pass


@scenario('document.feature', 'Update a document with controller', features_base_dir=FEATURES)
def test_doc_update_using_controller():
    pass


@scenario('document.feature', 'Make a new document and set creator field', features_base_dir=FEATURES)
def test_make_a_new_document_and_set_creator_field():
    pass


@scenario('document.feature', 'Make a new document and set revoked on the document', features_base_dir=FEATURES)
def test_make_a_new_document_and_set_revoked_on_the_document():
    pass


@scenario('authentication.feature', 'Make an auth token for allowed agent1 -> user1', features_base_dir=FEATURES)
def test_make_an_auth_token_for_allowed_agent1_user1():
    pass


@scenario('authentication.feature', 'Make an auth token for not allowed agent1 -> user0', features_base_dir=FEATURES)
def test_make_an_auth_token_for_not_allowed_agent1_user0():
    pass


@scenario('authentication.feature',
          'Make an auth token for not allowed agent1 revoked key -> user1',
          features_base_dir=FEATURES)
def test_make_an_auth_token_for_not_allowed_agent1_revoked_key_user1():
    pass


@scenario('authentication.feature',
          'Make an auth token for not allowed agent1 using delegation -> user1',
          features_base_dir=FEATURES)
def test_make_an_auth_token_for_allowed_agent1_using_delegation_user1():
    pass


@scenario('authentication.feature',
          'Make an auth token for not allowed agent1 using controller -> user1',
          features_base_dir=FEATURES)
def test_make_an_auth_token_for_allowed_agent1_using_controller_user1():
    pass
