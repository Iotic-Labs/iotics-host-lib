# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from __future__ import annotations

from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric.ec import EllipticCurvePrivateKey, EllipticCurvePublicKey

from iotic.lib.identity import Identifier, Document, Authentication

from .const import RESOLVER


@dataclass
class Identity:

    seed: str
    seed_master: bytes
    priv_ecdsa: EllipticCurvePrivateKey
    pub_ecdsa: EllipticCurvePublicKey
    id: str
    doc: Document.DIDDocument
    name: str
    token = ''

    @classmethod
    def create(cls, purpose: Identifier.DIDType, name: str, seed: str = None) -> Identity:
        if seed is None:
            seed = Identifier.new_seed(256)

        seed_master = Identifier.seed_to_master(seed)
        priv_ecdsa = Identifier.private_hex_to_ECDSA(
            Identifier.new_private_hex_from_path_str(seed_master, purpose, name)
        )
        pub_ecdsa = Identifier.private_ECDSA_to_public_ECDSA(priv_ecdsa)

        obj = cls(
            seed=seed,
            seed_master=seed_master,
            priv_ecdsa=priv_ecdsa,
            pub_ecdsa=pub_ecdsa,
            id=Identifier.make_identifier(Identifier.public_ECDSA_to_bytes(pub_ecdsa).hex()),
            doc=Document.new_did_document(purpose, priv_ecdsa, name=f'#{name}'),
            name=name
        )
        obj.__update_token()
        return obj

    def __update_token(self):
        self.token = Document.new_document_token(self.doc, RESOLVER, self.__get_full_id_for(self), self.priv_ecdsa)

    @staticmethod
    def __get_full_id_for(id_: Identity) -> str:
        return id_.doc.id + id_.doc.public_keys[0].id

    def delegate_to(self, controller: Identity) -> bool:
        delegate = (
            self.doc.add_control_delegation
            if self.doc.did_type == Identifier.DIDType.TWIN else
            self.doc.add_authentication_delegation
        )
        result = delegate(Document.new_delegation(
            f'#{controller.name}',
            self.__get_full_id_for(controller),
            Document.new_proof(self.id.encode('ascii'), controller.priv_ecdsa)
        ))
        if result:
            # token only valid with all delegations taken into account
            self.__update_token()
        return result

    def make_auth_token(self, auth_as: Identity, audience: str, duration: int) -> str:
        return Authentication.new_authentication_token(
            self.__get_full_id_for(self),
            auth_as.id,
            audience,
            duration,
            self.priv_ecdsa
        )
