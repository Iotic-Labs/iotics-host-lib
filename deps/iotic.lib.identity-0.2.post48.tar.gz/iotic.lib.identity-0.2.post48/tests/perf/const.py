# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from os import environ

from iotic.lib.identity.document import RESOLVER_ENV


MOCK_RESOLVER_ADDR = 'mock://resolver'

# If not specified, a mocked resolver will be used
RESOLVER = environ.setdefault(RESOLVER_ENV, MOCK_RESOLVER_ADDR)

# How many times to repeat each function
REPEATS = int(environ.get('REPEATS', '20'))

# If set, profile data will be dumped to disk with this prefix
PROFILE_PATH_PREFIX = environ.get('PROFILE_PATH_PREFIX')

# If set, a 'tot_time' summary of the profile will be shown for each benchmark
PROFILE_SUMMARY = 'PROFILE_SUMMARY' in environ

# If set, profiling information will not be collected. Only timins will be calculated
PROFILE_DISABLE = 'PROFILE_DISABLE' in environ
