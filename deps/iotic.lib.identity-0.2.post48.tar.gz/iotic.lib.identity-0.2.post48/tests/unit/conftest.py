# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import os
import importlib
import json
import logging
import sys
from unittest import mock

import pytest
from prometheus_client.registry import CollectorRegistry

from iotic.lib.identity import register_metrics
from iotic.lib.identity.resolver import HttpResolverClient, RESOLVER_ENV

from tests.unit.const import MOCK_RESOLVER_ADDR


def vector_const():
    """vector_const: Load test vectors json"""
    try:
        file_path = os.path.join(os.curdir, '..', '..', 'test_vectors.json')
        with open(file_path) as fpr:
            return json.load(fpr)
    except (json.JSONDecodeError, TypeError) as err:
        logging.error('Invalid json spec from %s', file_path)
        raise err
    except OSError as err:
        logging.error('Can not load file %s', file_path)
        raise err


@pytest.fixture
def save_resolver_env():
    # Why not monkeypatch? Because the tests decide what value to either assign (or remove completely)
    old = os.environ.get(RESOLVER_ENV)
    yield
    if old is not None:
        print('\n\n**** HAPPENS!!\n\n')
        os.environ[RESOLVER_ENV] = old


@pytest.fixture
def http_resolver() -> HttpResolverClient:
    return HttpResolverClient(MOCK_RESOLVER_ADDR)


# Uses a temporary registry just for SDK metrics testing
@pytest.fixture
def metrics_registry():
    registry = CollectorRegistry(auto_describe=True)
    register_metrics(registry=registry)
    return registry


@pytest.fixture
def without_prometheus():
    import iotic.lib.identity.metrics as metrics_module  # pylint: disable=import-outside-toplevel

    try:
        with mock.patch.dict(sys.modules, {'prometheus_client': None}):
            importlib.reload(metrics_module)
            yield
    finally:
        # prometheus-available version must be restored
        importlib.reload(metrics_module)
