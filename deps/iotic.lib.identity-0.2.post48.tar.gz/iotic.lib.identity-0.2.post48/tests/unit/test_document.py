# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

# flake8: noqa: E501
# pylint: disable=invalid-name,line-too-long,no-self-use

from os import environ
import json

import pytest
import unittest

import requests_mock

from iotic.lib.identity import Identifier
from iotic.lib.identity import Document

from .conftest import vector_const

TV = vector_const()


class TestMetadata(unittest.TestCase):
    def test_empty(self):
        m = Document.Metadata()
        assert m.__dict__() == {}  # pylint: disable=E1102

    def test_init_property(self):
        m = Document.Metadata('my label', 'my comment', 'http://my.url')
        assert m.label == 'my label'
        assert m.comment == 'my comment'
        assert m.url == 'http://my.url'

    def test_setter(self):
        m = Document.Metadata()
        m.label = 'label my'
        assert m.label == 'label my'
        m.comment = 'comment my'
        assert m.comment == 'comment my'
        m.url = 'http://url.my'
        assert m.url == 'http://url.my'

    def test_invalid(self):
        unicode_str = 'Unicode string 💪 💩'
        m = Document.Metadata()
        with pytest.raises(UnicodeEncodeError):
            m.label = unicode_str
        with pytest.raises(ValueError):
            m.label = 'a' * (Document.DOCUMENT_MAX_LABEL_LENGTH + 1)
        with pytest.raises(UnicodeEncodeError):
            m.comment = unicode_str
        with pytest.raises(ValueError):
            m.comment = 'a' * (Document.DOCUMENT_MAX_COMMENT_LENGTH + 1)
        with pytest.raises(UnicodeEncodeError):
            m.url = unicode_str
        with pytest.raises(ValueError):
            m.url = 'a' * (Document.DOCUMENT_MAX_URL_LENGTH + 1)

class TestKeyID(unittest.TestCase):
    def test_new_keyid(self):
        k = Document.new_keyid_publickey('#test', TV['ident']['user0']['pub_base58'])
        assert k.id == '#test'
        assert k.public_base58 == TV['ident']['user0']['pub_base58']

    def test_new_invalid(self):
        with pytest.raises(ValueError):
            Document.new_keyid_publickey('#test', 'invalid')


class TestDocument(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def setup(self):
        environ['RESOLVER'] = 'mock://resolver'

    def test_new_proof(self):
        method = Identifier.SeedMethod(TV['ident']['user1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['user1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'user', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)
        user_pub_b58 = Identifier.public_ECDSA_to_base58(Identifier.private_ECDSA_to_public_ECDSA(pk))

        # note: Not sure how to test new_proof as sig contains a random so different everytime
        user_proof = Document.new_proof(TV['ident']['user1']['id'].encode('ascii'), pk)

        assert Document.verify_proof(user_proof, TV['ident']['user1']['id'].encode('ascii'), user_pub_b58)

        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)
        agent_pub_b58 = Identifier.public_ECDSA_to_base58(Identifier.private_ECDSA_to_public_ECDSA(pk))

        agent_proof = Document.new_proof(TV['ident']['agent1']['id'].encode('ascii'), pk)

        assert Document.verify_proof(agent_proof, TV['ident']['agent1']['id'].encode('ascii'), agent_pub_b58)

        assert not Document.verify_proof(agent_proof, TV['ident']['agent1']['id'].encode('ascii'), user_pub_b58)
        assert not Document.verify_proof(agent_proof, TV['ident']['user1']['id'].encode('ascii'), agent_pub_b58)

    def test_new_document(self):
        method = Identifier.SeedMethod(TV['ident']['user1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['user1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'user', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        doc = Document.new_did_document(Identifier.DIDType.USER, pk)
        assert doc.id == TV['ident']['user1']['id']

    def test_new_document_token(self):
        method = Identifier.SeedMethod(TV['ident']['user1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['user1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'user', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        doc = Document.new_did_document(Identifier.DIDType.USER, pk)

        tkn = Document.new_document_token(doc, 'audience.example.com', doc.id + doc.public_keys[0].id, pk)
        assert isinstance(tkn, str)
        assert len(tkn) > 69

        assert Document.verify_document(tkn) is not None

    def test_verify_document(self):
        assert Document.verify_document(TV['ident']['user1']['ddo']) is not None
        assert Document.verify_document(TV['ident']['agent1']['ddo']) is not None

        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            assert Document.verify_document(TV['ident']['user1']['ddo_deleg']) is not None

    def test_verify_000_document(self):
        with requests_mock.Mocker() as m:
            for k, v in TV['old_docs'].items():
                result = json.dumps({'token': v})
                m.get('mock://resolver/1.0/discover/' + k, text=result)

            for _, v in TV['old_docs'].items():
                assert Document.verify_document(v)

    def test_find_issuer_agent_self(self):
        for control in (True, False):
            with requests_mock.Mocker() as m:
                result = json.dumps({'token': TV['ident']['agent1']['ddo']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

                issuer_key = Document.find_issuer_by_id(TV['ident']['agent1']['id'], TV['ident']['agent1']['id_name'], control)
                assert issuer_key is not None

    def test_find_issuer_agent_as_user_not_allowed(self):
        control = True
        with requests_mock.Mocker() as m:
            result = json.dumps({'token': TV['ident']['agent1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

            result = json.dumps({'token': TV['ident']['user1']['ddo']})
            m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

            issuer_key = Document.find_issuer_by_id(TV['ident']['user1']['id'], TV['ident']['agent1']['id_name'], control)
            assert issuer_key is None

    def test_find_issuer_agent_as_user_allowed(self):
        for control in (True, False):
            with requests_mock.Mocker() as m:
                result = json.dumps({'token': TV['ident']['user1']['ddo_deleg']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['user1']['id'], text=result)

                result = json.dumps({'token': TV['ident']['agent1']['ddo']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

                delegation_name = TV['agent_deleg']
                issuer_key = Document.find_issuer_by_id(TV['ident']['user1']['id'], TV['ident']['user1']['id'] + delegation_name, control)
                if control:
                    # Not control because only an authentication delegation
                    assert issuer_key is None
                else:
                    assert issuer_key is not None

    def test_find_issuer_agent_as_twin_not_allowed(self):
        for control in (True, False):
            with requests_mock.Mocker() as m:
                result = json.dumps({'token': TV['ident']['twin1']['ddo']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['twin1']['id'], text=result)

                result = json.dumps({'token': TV['ident']['agent1']['ddo']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

                issuer_key = Document.find_issuer_by_id(TV['ident']['twin1']['id'], TV['ident']['agent1']['id_name'], control)
                assert issuer_key is None

    def test_find_issuer_agent_twin_allowed(self):
        for control in (True, False):
            with requests_mock.Mocker() as m:
                result = json.dumps({'token': TV['ident']['twin1']['ddo_deleg']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['twin1']['id'], text=result)

                result = json.dumps({'token': TV['ident']['agent1']['ddo']})
                m.get('mock://resolver/1.0/discover/' + TV['ident']['agent1']['id'], text=result)

                issuer_key = Document.find_issuer_by_id(TV['ident']['twin1']['id'], TV['ident']['agent1']['id_name'], control)
                assert issuer_key is not None

                delegation_name = TV['agent_deleg']
                issuer_key = Document.find_issuer_by_id(TV['ident']['twin1']['id'], TV['ident']['twin1']['id'] + delegation_name, control)
                assert issuer_key is not None

    def test_set_controller(self):
        method = Identifier.SeedMethod(TV['ident']['user1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['user1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'user', 0)
        pk = Identifier.private_hex_to_ECDSA(pkhex)

        doc = Document.new_did_document(Identifier.DIDType.USER, pk)

        assert doc.controller is None

        doc.controller = TV['ident']['user0']['id']
        assert doc.controller == TV['ident']['user0']['id']

        with pytest.raises(ValueError):
            doc.controller = TV['ident']['twin1']['id']
        with pytest.raises(ValueError):
            doc.controller = ''

        tkn = Document.new_document_token(doc, 'audience.example.com', doc.id + doc.public_keys[0].id, pk)
        assert isinstance(tkn, str)
        assert len(tkn) > 69

        dc = Document.verify_document(tkn)
        re_doc = dc.doc

        assert re_doc.controller == doc.controller
