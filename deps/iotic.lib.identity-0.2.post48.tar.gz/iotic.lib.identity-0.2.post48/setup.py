# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from os import path
from setuptools import setup, find_packages

PKGDIR = path.abspath(path.dirname(__file__))
with open(path.join(PKGDIR, 'README.md'), encoding='utf-8') as f:
    LONG_DESCRIPTION = f.read()

with open(path.join(PKGDIR, 'VERSION')) as version_file:
    VERSION = version_file.read().strip()

setup(
    name='iotic.lib.identity',
    description='Identity functions',
    long_description=LONG_DESCRIPTION,
    long_description_content_type='text/markdown',
    version=VERSION,
    author='Iotic Labs Ltd',
    author_email='info@iotic-labs.com',
    url='https://iotic-labs.com',
    packages=find_packages(),
    zip_safe=True,
    python_requires='>3.5',
    install_requires=[
        'requests>=2.22.0',
        'base58==2.0.1',
        'PyJWT==1.7.1',
        'mnemonic==0.19',
        'cryptography>=3.2,<4',
    ],
    extras_require={
        'test': [
            'pytest-bdd==4.0.1',
            'requests-mock==1.8.0',
        ],
        'metrics': [
            'prometheus-client==0.9.0'
        ]
    }
)
