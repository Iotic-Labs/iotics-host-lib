TIMESTEP_FORMAT = '%Y-%m-%dT%H:%M:%SZ'
RFC1123_FORMAT = '%a, %d %b %Y %H:%M:%S %Z'
IOTICS_DATA_URI = 'http://data.iotics.com/'
IOTICS_NS_URI = 'http://data.iotics.com/ns/'
