from os.path import abspath, dirname, join

from setuptools import setup

PKGDIR = abspath(dirname(__file__))

with open(join(PKGDIR, 'VERSION')) as version_file:
    VERSION = version_file.read().strip()


def get_requirements():
    with open(join(abspath(dirname(__file__)), 'requirements.txt')) as fd:
        return fd.read().strip('\n').split('\n')


if __name__ == '__main__':
    setup(install_requires=get_requirements(),
          version=VERSION,
          extras_require={'package': ['twine==3.1.1',
                                      'wheel==0.33.6', ]}
          )
