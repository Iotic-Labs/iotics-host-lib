# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from contextlib import contextmanager
from enum import Enum, auto
from time import monotonic

try:
    from prometheus_client import Counter, Histogram, REGISTRY
    _IMPORT_FAILURE = None
except ImportError as ex:
    _IMPORT_FAILURE = ex

ALL_METRICS = []


def register_metrics(registry=None):
    """Register all identity SDK prometheus metrics with the given registry (or default one, if not specified)."""
    if _IMPORT_FAILURE:
        raise RuntimeError(
            'missing dependencies for metrics. Please install this library with the "metrics" extra'
        ) from _IMPORT_FAILURE
    if registry is None:
        registry = REGISTRY
    for metric in ALL_METRICS:
        registry.register(metric)


# ----------------------------------------------------------------------------------------------------------------------

class ResolverErrorType(Enum):
    """Label values for METRIC_RESOLVER_ERRORS"""

    CONNECTION = auto()
    """Connection to resolver failed"""
    SERVER = auto()
    """A server-related error occurred"""
    TIMEOUT = auto()
    """The request to resolver timed out"""
    NOTFOUND = auto()
    """The server reports that the requested document does not exist (during discovery)"""


class ResolverCallType(Enum):
    """Label values for METRIC_RESOLVER_REQUEST_LATENCY"""

    GET = auto()
    """Get a document (token)"""
    REGISTER = auto()
    """Retrieve a document (token)"""


# Individual metrics

if not _IMPORT_FAILURE:

    def add(metric):
        ALL_METRICS.append(metric)
        return metric

    METRIC_RESOLVER_ERRORS = add(Counter(
        'errors',
        'Resolver client errors by error type',
        namespace='iotics_identity',
        subsystem='resolver',
        # One of ResolverErrorType (name)
        labelnames=('type',),
        registry=None
    ))

    METRIC_RESOLVER_REQUEST_LATENCY = add(Histogram(
        'request_latency',
        'Successful resolver call duration by request type',
        namespace='iotics_identity',
        subsystem='resolver',
        # One of ResolverCallType (name)
        labelnames=('type',),
        unit='seconds',
        registry=None
    ))


# ----------------------------------------------------------------------------------------------------------------------

# Metrics functions called internally

def resolver_errors_inc(type_: ResolverErrorType):
    if _IMPORT_FAILURE:
        return
    METRIC_RESOLVER_ERRORS.labels(type=type_.name).inc()


# Note: Only times successful requests
@contextmanager
def resolver_request_latency_observe(type_: ResolverCallType):
    if _IMPORT_FAILURE:
        yield
        return
    start = monotonic()
    yield
    METRIC_RESOLVER_REQUEST_LATENCY.labels(type=type_.name).observe(monotonic() - start)
