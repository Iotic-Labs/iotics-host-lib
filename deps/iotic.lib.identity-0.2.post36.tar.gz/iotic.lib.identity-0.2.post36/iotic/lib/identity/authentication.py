# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from datetime import datetime

import jwt

from cryptography.hazmat.primitives.asymmetric import ec

# Max duration (secs) of authentication token
MAX_DURATION = 86400


def new_challenge_token(iss: str, aud: str, proof: str, private_ecdsa: ec.EllipticCurvePrivateKey) -> str:
    """new_challenge_token: Make a challenge token for issuer to work on audiences behalf"""
    return jwt.encode({'iss': iss, 'aud': aud, 'proof': proof}, private_ecdsa, algorithm='ES256')


def new_authentication_token(iss: str, sub: str, aud: str, duration: int,
                             private_ecdsa: ec.EllipticCurvePrivateKey) -> str:
    """new_authentication_token: Make a token for issuer to authenticate as subject to audience"""
    tnow = int(datetime.now().timestamp())
    if 0 < duration > MAX_DURATION:
        raise ValueError(f'Duration must be >0 and <{MAX_DURATION}')
    return jwt.encode({
        'iss': iss,
        'aud': aud,
        'sub': sub,
        'iat': tnow,
        'exp': tnow + duration
    }, private_ecdsa, algorithm='ES256')
