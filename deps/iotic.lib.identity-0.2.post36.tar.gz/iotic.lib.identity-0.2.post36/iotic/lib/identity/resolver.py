# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from abc import ABC, abstractmethod
from functools import wraps
from http import HTTPStatus
from os import environ
from typing import Union

import requests

from iotic.lib.identity.exceptions import IdentityNotFound, ServerError, CommunicationError, \
    CommunicationTimeoutError, InvalidConfiguration
from iotic.lib.identity.metrics import ResolverErrorType as ErrorType, ResolverCallType as CallType, \
    resolver_errors_inc, resolver_request_latency_observe

RESOLVER_ENV = 'RESOLVER'
"""Environment variable name from which resolver address is loaded"""


class ResolverClient(ABC):
    """Internal interface to communicate with resolver. Used by identity client. Note that input validation is not
    expected to be performed here."""

    @abstractmethod
    def get_token(self, did_id: str) -> str:
        """Retrieve the given did document (without name) as an encoded token. Raises one of the ResolverError
        exceptions on failure, or IdentityNotFound if the given did does not exist.
        """
        raise NotImplementedError

    @abstractmethod
    def register_token(self, token: str) -> bool:
        """Register a DDO with the resolver. Raises one of the ResolverError exceptions on failure."""
        raise NotImplementedError


# Decorator for use by resolver implementations to update metrics
def with_call_metrics(type_: CallType):
    def wrapped(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                with resolver_request_latency_observe(type_):
                    return func(*args, **kwargs)
            except CommunicationTimeoutError:
                resolver_errors_inc(ErrorType.TIMEOUT)
                raise
            except CommunicationError:
                resolver_errors_inc(ErrorType.CONNECTION)
                raise
            except IdentityNotFound:
                resolver_errors_inc(ErrorType.NOTFOUND)
                raise
            except ServerError:
                resolver_errors_inc(ErrorType.SERVER)
                raise

        return wrapper

    return wrapped


class HttpResolverClient(ResolverClient):

    def __init__(self, address: str, timeout: Union[int, float] = 60.0):
        """Instantiate a new http resolver client with the given address. The optional timeout defaults to 60s.
        If set to zero, requests will have no timeout.
        """
        if not isinstance(address, str):
            raise InvalidConfiguration('address must be a string')
        self.address = address
        if not isinstance(timeout, (int, float)):
            raise InvalidConfiguration('timeout must be an integer or floating point number')
        if timeout < 0:
            raise InvalidConfiguration('timeout must be non-negative')
        # 0 -> infinite timeout
        self.timeout = timeout or None

    @classmethod
    def from_env(cls, **kwargs):
        """Instantiate client using configuration from environment variables. This includes 'RESOLVER' which
        must contain the remote address of the resolver endpoint. Any keyword arguments are passed on to the
        constructor.
        """
        address = environ.get(RESOLVER_ENV)
        if not address:
            raise InvalidConfiguration(f'Resolver address env var ({RESOLVER_ENV}) missing or empty')
        return cls(address, **kwargs)

    @with_call_metrics(CallType.GET)
    def get_token(self, did_id: str) -> str:
        try:
            rsp = requests.get(
                f'{self.address}/1.0/discover/{did_id}',
                timeout=self.timeout
            )
        except requests.Timeout as exc:
            raise CommunicationTimeoutError(f'Token retrieval from {self.address} timed out') from exc
        except requests.RequestException as exc:
            raise CommunicationError(f'Failed to retrieve token from {self.address}') from exc
        try:
            rsp.raise_for_status()
        except requests.HTTPError as exc:
            if rsp.status_code == HTTPStatus.NOT_FOUND:
                raise IdentityNotFound(f'Identity token for {did_id} not found') from exc
            raise ServerError('Identity token could not be retrieved') from exc
        try:
            return rsp.json()['token']
        except (KeyError, ValueError) as exc:
            raise ServerError('Unexpected response format received') from exc

    @with_call_metrics(CallType.REGISTER)
    def register_token(self, token: str):
        try:
            rsp = requests.post(
                f'{self.address}/1.0/register',
                headers={'Content-type': 'text/plain'},
                data=token,
                timeout=self.timeout
            )
        except requests.Timeout as exc:
            raise CommunicationTimeoutError(f'Token registration with {self.address} timed out') from exc
        except requests.RequestException as exc:
            raise CommunicationError(f'Failed to register token with {self.address}') from exc
        try:
            rsp.raise_for_status()
        except requests.HTTPError as exc:
            raise ServerError('Identity token could not be registered') from exc
