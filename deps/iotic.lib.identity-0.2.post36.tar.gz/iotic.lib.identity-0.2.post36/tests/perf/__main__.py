# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

from __future__ import annotations

from contextlib import contextmanager
import cProfile
import inspect
from pstats import Stats
from time import perf_counter

from iotic.lib.identity import Identifier, Authentication
from iotic.lib.identity.exceptions import NotAllowed

from .const import PROFILE_PATH_PREFIX, REPEATS, PROFILE_SUMMARY, PROFILE_DISABLE
from .identity import Identity
from .resolver import get_resolver


def get_caller_name(depth=1):
    return inspect.getouterframes(inspect.currentframe(), 2)[1 + depth][3]


@contextmanager
def profile_ctx(profile_name):
    """Collects profiling information and dumps to disk depending on configuration, unless profiling disabled"""
    if PROFILE_DISABLE:
        yield
        return

    profiler = cProfile.Profile()
    profiler.enable()
    try:
        yield
    finally:
        profiler.disable()

    if PROFILE_PATH_PREFIX:
        profiler.dump_stats(f'{PROFILE_PATH_PREFIX}{profile_name}.prof')

    if PROFILE_SUMMARY:
        stats = Stats(profiler)
        stats.sort_stats('tottime')
        stats.print_stats(10)


def profile(resolver, func, *args, exc=None, **kwargs):
    """Profile the given function"""
    name = get_caller_name()
    resolver.reset()

    # Function wrapper so repeated runs which have expected exceptions can run in same manner as ones which do not
    if exc is None:
        actual_func = func
    else:
        def actual_func(*args, **kwargs):
            try:
                func(*args, **kwargs)
            except exc:
                pass
            else:
                assert False, f'did not except with {exc}'

    with profile_ctx(name):
        # profiler doesn't provide easy access to total time, so record separately
        start = perf_counter()
        for _ in range(REPEATS):
            actual_func(*args, **kwargs)
        stop = perf_counter()

    print(f'{name},{(stop - start):.3f},{resolver.calls}')


def bench_verify_authorised_for_user(resolver, agent, user):
    jwt = agent.make_auth_token(user, 'http://somewhere.org/interesting', 360)

    profile(resolver, Authentication.verify_authentication, jwt)


def bench_verify_authorised_for_twin_and_control_allowed(resolver, agent, twin):  # pylint: disable=invalid-name
    jwt = agent.make_auth_token(twin, 'http://somewhere.org/interesting', 360)
    verify_auth = Authentication.verify_authentication
    check_allowed = Authentication.check_allowed

    def func():
        iss = verify_auth(jwt)['iss']
        check_allowed(iss, twin.id, control_only=True)

    profile(resolver, func)


def bench_control_allowed(resolver, agent, twin):
    jwt = agent.make_auth_token(twin, 'http://somewhere.org/interesting', 360)
    iss = Authentication.verify_authentication(jwt)['iss']

    profile(resolver, Authentication.check_allowed, iss, twin.id, control_only=True)


def bench_verify_unauthorised_for_user(resolver, agent, user):
    jwt = agent.make_auth_token(user, 'http://somewhere.org/interesting', 360)

    profile(resolver, Authentication.verify_authentication, jwt, exc=NotAllowed)


def bench_verify_authorised_and_control_disallowed(resolver, agent, user, twin):  # pylint: disable=invalid-name
    jwt = agent.make_auth_token(user, 'http://somewhere.org/interesting', 360)

    verify_auth = Authentication.verify_authentication
    check_allowed = Authentication.check_allowed

    def func():
        try:
            res = verify_auth(jwt)
        except:
            assert False, 'should not except on verify call'
        assert not check_allowed(res['iss'], twin.id, control_only=True), 'should not allow'

    profile(resolver, func)


def main():
    seed = 'b33f' * 8
    start = perf_counter()

    user = Identity.create(Identifier.DIDType.USER, 'perf-user1', seed=seed)
    agent = Identity.create(Identifier.DIDType.AGENT, 'perf-agent1', seed=seed)
    agent2 = Identity.create(Identifier.DIDType.AGENT, 'perf-agent2', seed=seed)
    twin = Identity.create(Identifier.DIDType.TWIN, 'perf-twin1', seed=seed)
    twin2 = Identity.create(Identifier.DIDType.TWIN, 'perf-twin2', seed=seed)

    assert user.delegate_to(agent)
    assert twin.delegate_to(agent)

    stop = perf_counter()
    print('func,total_time,resolver_calls')
    print(f'local_setup,{stop - start:.3f},0')

    with get_resolver((user, agent, agent2, twin, twin2)) as resolver:
        bench_verify_authorised_for_user(resolver, agent, user)
        bench_verify_authorised_for_twin_and_control_allowed(resolver, agent, twin)
        bench_control_allowed(resolver, agent, twin)
        bench_verify_unauthorised_for_user(resolver, agent2, user)
        bench_verify_authorised_and_control_disallowed(resolver, agent, user, twin2)


if __name__ == '__main__':
    main()
