# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

# flake8: noqa: E501
# pylint: disable=invalid-name,line-too-long,no-self-use

import unittest
import pytest

from iotic.lib.identity import Identifier

from .conftest import vector_const

TV = vector_const()


class TestIdentifier(unittest.TestCase):
    def test_make_identifier(self):
        assert Identifier.make_identifier(TV['ident']['user0']['pub']) == TV['ident']['user0']['id']
        method = Identifier.SeedMethod(TV['ident']['agent1']['seed_method'])
        md = Identifier.seed_to_master(TV['ident']['agent1']['seed'], method=method)
        pkhex = Identifier.new_private_hex_from_path(md, 'agent', 0)
        assert pkhex == Identifier.new_private_hex_from_path_str(md, 'agent', '00')

        pk = Identifier.private_hex_to_ECDSA(pkhex)
        pu = Identifier.public_ECDSA_to_bytes(Identifier.private_ECDSA_to_public_ECDSA(pk))
        assert Identifier.make_identifier(pu.hex()) == TV['ident']['agent1']['id']

    def test_new_private_hex_from_path(self):
        md = bytearray.fromhex(TV['ident']['user0']['master_hex'])
        assert Identifier.new_private_hex_from_path(md, 'user', 0) == TV['ident']['user0']['priv']

    def test_seed_to_mnemonic(self):
        assert Identifier.seed_to_mnemonic(TV['ident']['user0']['seed']) == TV['ident']['user0']['mnemonic']
        assert Identifier.seed_to_mnemonic(TV['ident']['user1']['seed']) == TV['ident']['user1']['mnemonic']
        assert Identifier.seed_to_mnemonic(TV['ident']['agent1']['seed']) == TV['ident']['agent1']['mnemonic']

    def test_mnemonic_to_seed(self):
        assert Identifier.mnemonic_to_seed(TV['ident']['user0']['mnemonic']) == TV['ident']['user0']['seed']
        assert Identifier.mnemonic_to_seed(TV['ident']['user1']['mnemonic']) == TV['ident']['user1']['seed']
        assert Identifier.mnemonic_to_seed(TV['ident']['agent1']['mnemonic']) == TV['ident']['agent1']['seed']

    def test_seed_to_master(self):
        method = Identifier.SeedMethod(TV['ident']['user0']['seed_method'])
        master = Identifier.seed_to_master(TV['ident']['user0']['seed'], method=method)
        assert master == bytearray.fromhex(TV['ident']['user0']['master_hex'])
        master = Identifier.seed_to_master(TV['ident']['user0']['seed'], TV['password'].encode('ascii'), method=method)
        assert master == bytearray.fromhex(TV['ident']['user0']['master_hex_p'])

    def test_compare_identifier(self):
        assert Identifier.compare_identifier_only(TV['ident']['user0']['id'], TV['ident']['user0']['id'])
        assert Identifier.compare_identifier_only(TV['ident']['user0']['id'], TV['ident']['user0']['id_name'])
        assert not Identifier.compare_identifier_only(TV['ident']['agent1']['id'], TV['ident']['user0']['id'])

    def test_split_name_off_id(self):
        assert Identifier.split_name_off_id('fish#cat') == '#cat'
        assert Identifier.split_name_off_id('#cat') == '#cat'
        assert Identifier.split_name_off_id(TV['ident']['user0']['id_name']) == '#user-0'
        assert Identifier.split_name_off_id(TV['ident']['user0']['id']) is None

    def test_private_hex_to_ECDSA(self):
        privEC = Identifier.private_hex_to_ECDSA(TV['ident']['user0']['priv'])
        pubEC = Identifier.private_ECDSA_to_public_ECDSA(privEC)
        assert Identifier.public_ECDSA_to_bytes(pubEC) == bytearray.fromhex(TV['ident']['user0']['pub'])

    def test_public_ECDSA_to_bytes(self):
        pubEC = Identifier.public_bytes_to_ECDSA(bytearray.fromhex(TV['ident']['user0']['pub']))
        assert Identifier.public_ECDSA_to_bytes(pubEC) == bytearray.fromhex(TV['ident']['user0']['pub'])

    def test_public_ECDSA_to_base58(self):
        pubEC = Identifier.public_bytes_to_ECDSA(bytearray.fromhex(TV['ident']['user0']['pub']))
        assert Identifier.public_ECDSA_to_base58(pubEC) == TV['ident']['user0']['pub_base58']

    def test_public_base58_to_ECDSA(self):
        pubEC = Identifier.public_base58_to_ECDSA(TV['ident']['user0']['pub_base58'])
        assert Identifier.public_ECDSA_to_bytes(pubEC) == bytearray.fromhex(TV['ident']['user0']['pub'])

    def test_validate_identifier(self):
        assert Identifier.validate_identifier(TV['ident']['user0']['id'])
        assert Identifier.validate_identifier(TV['ident']['user1']['id'])
        assert Identifier.validate_identifier(TV['ident']['agent1']['id'])

    def test_new_seed(self):
        buf = []
        for x in (128, 256):
            for _ in range(10):
                z = Identifier.new_seed(x)
                assert len(z) == int(x / 4)
                assert z not in buf
                buf.append(z)

    def test_validate_key_name(self):
        assert Identifier.validate_key_name('#a12')
        assert Identifier.validate_key_name('#aA-12_')
        assert Identifier.validate_key_name('#key-0')
        assert Identifier.validate_key_name('#default')
        assert Identifier.validate_key_name('#qwertyuiop-_asdfghjk1mnb')

        with pytest.raises(ValueError):
            Identifier.validate_key_name('#')
        with pytest.raises(ValueError):
            Identifier.validate_key_name('#a#')
        with pytest.raises(ValueError):
            Identifier.validate_key_name('##aj12kh')
        with pytest.raises(ValueError):
            Identifier.validate_key_name('##aj12kh#')
        with pytest.raises(ValueError):
            Identifier.validate_key_name('##aj12kh#abc')
        with pytest.raises(ValueError):
            Identifier.validate_key_name('#aA-_%')
        with pytest.raises(ValueError):
            Identifier.validate_key_name('#aA-_#')

        with pytest.raises(ValueError):
            # Too long # + 25 char
            Identifier.validate_key_name('#qwertyuiop-_asd2ghjklmnbR')

    def test_bad_id(self):
        for n in TV['bad_id']:
            with pytest.raises(ValueError):
                Identifier.validate_identifier(n)

    def test_bad_id_name(self):
        for n in TV['bad_id_name']:
            with pytest.raises(ValueError):
                Identifier.validate_identifier(n)
