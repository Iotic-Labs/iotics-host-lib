# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

# pylint: disable=unused-argument

from http import HTTPStatus
import json
from os import environ

import pytest
import requests

from iotic.lib.identity.exceptions import InvalidConfiguration, ServerError, CommunicationError, \
    CommunicationTimeoutError, IdentityNotFound
from iotic.lib.identity.metrics import ResolverCallType as CallType, ResolverErrorType as ErrorType
from iotic.lib.identity.resolver import HttpResolverClient, RESOLVER_ENV

from tests.unit.const import MOCK_RESOLVER_ADDR
from tests.unit.helpers import check_metric_non_zero


def check_latency_metric_non_zero(registry, type_: CallType):
    check_metric_non_zero(
        registry, 'iotics_identity_resolver_request_latency_seconds_count', labels={'type': type_.name}
    )


def check_error_metric_non_zero(registry, type_: ErrorType):
    check_metric_non_zero(registry, 'iotics_identity_resolver_errors_total', labels={'type': type_.name})


def test_new_invalid_address():
    with pytest.raises(InvalidConfiguration, match='address'):
        HttpResolverClient(1)


@pytest.mark.parametrize('value', ('aha', -1))
def test_new_invalid_timeout(value):
    with pytest.raises(InvalidConfiguration, match='timeout'):
        HttpResolverClient('addr', timeout=value)


def test_from_env(save_resolver_env):
    environ[RESOLVER_ENV] = 'http://somewhere'
    client = HttpResolverClient.from_env()
    assert client.address == 'http://somewhere'
    assert client.timeout == 60.0

    client = HttpResolverClient.from_env(timeout=45)
    assert client.address == 'http://somewhere'
    assert client.timeout == 45


def test_from_env_no_address(save_resolver_env):
    environ.pop(RESOLVER_ENV, None)

    with pytest.raises(InvalidConfiguration, match='missing or empty'):
        HttpResolverClient.from_env()


def test_get_token_successful(requests_mock, http_resolver, metrics_registry):
    did_id = 'did:iotics:iotblah'
    result = json.dumps({'token': 'aha'})
    requests_mock.get(f'{MOCK_RESOLVER_ADDR}/1.0/discover/{did_id}', text=result)

    assert http_resolver.get_token(did_id) == 'aha'
    # Default timeout
    assert requests_mock.request_history[0].timeout == http_resolver.timeout

    check_latency_metric_non_zero(metrics_registry, CallType.GET)


def test_get_token_invalid_response(requests_mock, http_resolver, metrics_registry):
    did_id = 'did:iotics:iotblah'
    requests_mock.get(f'{MOCK_RESOLVER_ADDR}/1.0/discover/{did_id}', text='not json')

    with pytest.raises(ServerError, match='Unexpected response format'):
        http_resolver.get_token(did_id)

    check_error_metric_non_zero(metrics_registry, ErrorType.SERVER)


@pytest.mark.parametrize('code,exc,exc_msg,metric_type', (
    (HTTPStatus.NOT_FOUND, IdentityNotFound, 'Identity token.* not found', ErrorType.NOTFOUND),
    # Note: Currently server 5xx & client 4xx are reported via same exception
    (HTTPStatus.UNAUTHORIZED, ServerError, 'Identity token could not be retrieved', ErrorType.SERVER),
    (HTTPStatus.BAD_GATEWAY, ServerError, 'Identity token could not be retrieved', ErrorType.SERVER)
))
def test_get_token_http_error(requests_mock, http_resolver, metrics_registry, code, exc, exc_msg, metric_type):
    did_id = 'did:iotics:iotblah'
    requests_mock.get(f'{MOCK_RESOLVER_ADDR}/1.0/discover/{did_id}', status_code=code)

    with pytest.raises(exc, match=exc_msg):
        http_resolver.get_token(did_id)

    if metric_type:
        check_error_metric_non_zero(metrics_registry, metric_type)


@pytest.mark.parametrize('raise_exc,exc,exc_msg,metric_type', (
    (requests.exceptions.ConnectTimeout, CommunicationTimeoutError, 'Token retrieval.+timed out', ErrorType.TIMEOUT),
    (requests.exceptions.TooManyRedirects, CommunicationError, 'Failed to retrieve token from', ErrorType.CONNECTION)
))
def test_get_token_conn_error(requests_mock, http_resolver, metrics_registry, raise_exc, exc, exc_msg, metric_type):
    did_id = 'did:iotics:iotblah'
    requests_mock.get(f'{MOCK_RESOLVER_ADDR}/1.0/discover/{did_id}', exc=raise_exc)

    with pytest.raises(exc, match=exc_msg):
        http_resolver.get_token(did_id)

    check_error_metric_non_zero(metrics_registry, metric_type)


def test_register_token_successful(requests_mock, http_resolver, metrics_registry):
    token = 'blah'
    requests_mock.post(
        f'{MOCK_RESOLVER_ADDR}/1.0/register', request_headers={'Content-type': 'text/plain'}, text='{}'
    )

    http_resolver.register_token(token)
    req = requests_mock.request_history[0]
    assert req.body == token
    assert req.timeout == http_resolver.timeout

    check_latency_metric_non_zero(metrics_registry, CallType.REGISTER)


@pytest.mark.parametrize('code,exc,exc_msg,metric_type', (
    (HTTPStatus.UNAUTHORIZED, ServerError, 'Identity token could not be registered', ErrorType.SERVER),
    (HTTPStatus.BAD_GATEWAY, ServerError, 'Identity token could not be registered', ErrorType.SERVER)
))
def test_register_token_http_error(requests_mock, http_resolver, metrics_registry, code, exc, exc_msg, metric_type):
    requests_mock.post(f'{MOCK_RESOLVER_ADDR}/1.0/register', status_code=code)

    with pytest.raises(exc, match=exc_msg):
        http_resolver.register_token('blah')

    check_error_metric_non_zero(metrics_registry, metric_type)


@pytest.mark.parametrize('raise_exc,exc,exc_msg,metric_type', (
    (requests.exceptions.ConnectTimeout, CommunicationTimeoutError, 'Token registration.+timed out', ErrorType.TIMEOUT),
    (requests.exceptions.TooManyRedirects, CommunicationError, 'Failed to register token with', ErrorType.CONNECTION)
))
def test_register_token_conn_error(
        requests_mock, http_resolver, metrics_registry, raise_exc, exc, exc_msg, metric_type
):
    requests_mock.post(f'{MOCK_RESOLVER_ADDR}/1.0/register', exc=raise_exc)

    with pytest.raises(exc, match=exc_msg):
        http_resolver.register_token('blah')

    check_error_metric_non_zero(metrics_registry, metric_type)
