# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

import re
from typing import Mapping

from prometheus_client.exposition import generate_latest
from prometheus_client.registry import CollectorRegistry


# Note: labels must be in the same order as specified in code
def check_metric_non_zero(registry: CollectorRegistry, metric_name: str, labels: Mapping[str, str] = None):
    output = generate_latest(registry=registry)
    if labels:
        label_match = ".*".join(f'{name}="{value}"' for name, value in labels.items())
    else:
        label_match = ''
    # E.g.: iotics_identity_resolver_request_latency_seconds_created{type="GET"} 1.2
    result = re.search(fr'(?m)^{metric_name}.+{label_match}.*\s+([\d\.]+)$'.encode('utf8'), output)
    assert result
    assert float(result.group(1)) > 0
