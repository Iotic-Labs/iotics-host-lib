# Copyright (c) 2020 Iotic Labs Ltd. All rights reserved.

# Note: This suite is only for testing general metrics support behaviour. Specific metrics usage is tested together with
# the associated functionality.

# pylint: disable=import-outside-toplevel,invalid-name,unused-argument

import pytest


def test_metrics_import_default():
    from iotic.lib.identity.metrics import register_metrics

    # Should not raise exception (with prometheus installed)
    register_metrics()


def test_metrics_import_when_prometheus_unavailable(without_prometheus):
    from iotic.lib.identity.metrics import register_metrics

    with pytest.raises(
            RuntimeError, match='missing dependencies for metrics. Please install this library with the "metrics" extra'
    ):
        register_metrics()


# Why not pytest.mark.parametrize? Because this is supposed to show that all required pieces from the module can be
# used (no-op) despite lack of missing dependencies.
def test_metrics_functions_callable_when_prometheus_unavailable(without_prometheus):
    from iotic.lib.identity.metrics import resolver_errors_inc, resolver_request_latency_observe, ResolverCallType, \
        ResolverErrorType

    resolver_errors_inc(ResolverErrorType.SERVER)
    with resolver_request_latency_observe(ResolverCallType.GET):
        pass
