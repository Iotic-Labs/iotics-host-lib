Python Client over REST
=======================

Prerequisites
-------------

> activate your own python virtual environment



Build
-----
To generate the client:  
`make package-client`

